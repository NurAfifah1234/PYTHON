from stringcolor import *

print(cs("selamat datang", "blue", "white"))
print(bold("selamat datang"))
print(underline("selamat datang"))
print(underline("selamat datang").bold())
print(cs("selamat datang", "blue", "yellow").underline())